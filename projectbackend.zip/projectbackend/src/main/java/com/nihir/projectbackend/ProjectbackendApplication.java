package com.nihir.projectbackend;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.nihir.projectbackend.model.Library;
import com.nihir.projectbackend.repository.LibraryRepository;

@SpringBootApplication
public class ProjectbackendApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(ProjectbackendApplication.class, args);
	}
	@Autowired
    private LibraryRepository libraryRepository;
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		this.libraryRepository.save(new Library("war and Peace", "Tolstoye", "HarperColllins","Available"));
		this.libraryRepository.save(new Library("Mein kampf", "Adolf Hitler", "Macmillan Publishers"," Not Available"));
		this.libraryRepository.save(new Library("Time Machine", "H.G Wells", "McGraw-Hill ","Available"));
		this.libraryRepository.save(new Library("Divine Comedy", "Dante", "Simon Schuster","Not Available"));
		this.libraryRepository.save(new Library("Rich Dad Poor Dad", "Robert Kiyosaki", "Warner Books Ed","Available"));
		
	}

}
