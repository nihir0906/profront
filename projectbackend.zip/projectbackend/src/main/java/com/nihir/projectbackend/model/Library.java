package com.nihir.projectbackend.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "Library")
public class Library {
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(name ="booktitle")
	private String bookTitle;
	@Column(name ="authorname")
	private String authorName;
	@Column(name ="publisher")
	private String publisher;
	@Column(name ="availability")
	private String availability;
	
	public Library() {}
	
	public Library(String bookTitle, String authorName, String publisher,String availability) {
		super();
        this.bookTitle = bookTitle;
        this.authorName = authorName;
        this.publisher = publisher;
        this.availability = availability;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getBookTitle() {
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisherName(String publisher) {
		this.publisher = publisher;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	
}


